# bernoulli_moivre

Библиотека для вычисления вероятностей по формуле Бернулли и формулам Муавра–Лапласа.

## Установка

```bash
pip install bernoulli-moivre
```

*Глобин Никита Анатольевич 1032240005*

*Казначеев Сергей Ильич 1132240693*# Bernoulli_moivre
# Bernoulli_moivre
